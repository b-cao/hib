package cs4347.hibernateProject.ecomm.services.impl;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

//May not be needed
import javax.persistence.Query;

import cs4347.hibernateProject.ecomm.entity.Product;
import cs4347.hibernateProject.ecomm.services.ProductPersistenceService;
import cs4347.hibernateProject.ecomm.util.DAOException;

public class ProductPersistenceServiceImpl implements ProductPersistenceService
{
	private EntityManager em;

	public ProductPersistenceServiceImpl(EntityManager em)
	{
		this.em = em;
	}
	
	@Override
	public Product create(Product product) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		em.persist(product);
		em.getTransaction().commit();
		em.close();
		factory.close();
		return product;
	}

	@Override
	public Product retrieve(Long id) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		Product product = em.find(Product.class, id);
		
		//Display product information to console if you want to
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		return product;
	}

	@Override
	public Product update(Product product) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		
		//May work incorrectly.
		//If this does not work, use the udate example in slides
		//	and manually overwrite all new values to the product
		return em.merge(product);
	}

	@Override
	public void delete(Long id) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		Product product = em.find(Product.class, id);
		em.remove(product);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

	@Override
	public Product retrieveByUPC(String upc) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		Product product = em.find(Product.class, upc);
		
		//Display product information to console if you want to
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		return product;
	}

	@Override
	public List<Product> retrieveByCategory(int category) throws SQLException, DAOException
	{
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		
		Query q = em.createQuery("SELECT p FROM Product p WHERE :element in elements(p.elements)");
		q.setParameter("element", category);
		List<Product> result = q.getResultList();
		
		em.close();
		factory.close();
		return result;
	}

}
