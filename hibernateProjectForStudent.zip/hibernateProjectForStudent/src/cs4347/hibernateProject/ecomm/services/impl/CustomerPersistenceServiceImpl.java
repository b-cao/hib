package cs4347.hibernateProject.ecomm.services.impl;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import cs4347.hibernateProject.ecomm.entity.Customer;
import cs4347.hibernateProject.ecomm.entity.Product;
import cs4347.hibernateProject.ecomm.services.CustomerPersistenceService;
import cs4347.hibernateProject.ecomm.util.DAOException;

public class CustomerPersistenceServiceImpl implements CustomerPersistenceService
{
	private EntityManager em;

	public CustomerPersistenceServiceImpl(EntityManager em)
	{
		this.em = em;
	}
	
	/**
	 */
	@Override
	public Customer create(Customer customer) throws SQLException, DAOException
	{
		return null;
	}

	@Override
	public Customer retrieve(Long id) 
	{
		return null;
	}

	@Override
	public Customer update(Customer c1) throws SQLException, DAOException
	{
		return null;
	}

	@Override
	public void delete(Long id) throws SQLException, DAOException
	{

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("jpa-simple_company");
		em = factory.createEntityManager();
		em.getTransaction().begin();
		Customer cust = em.find(Customer.class, id);
		em.remove(cust);
		em.getTransaction().commit();
		em.close();
		factory.close();
	}

	@Override
	public List<Customer> retrieveByZipCode(String zipCode) throws SQLException, DAOException
	{
		return null;
	}

	@Override
	public List<Customer> retrieveByDOB(Date startDate, Date endDate) throws SQLException, DAOException
	{
		return null;
	}
}
