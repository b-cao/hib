package cs4347.hibernateProject.ecomm.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Address", uniqueConstraints = {})
public class Address 
{
	private Long id;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipcode;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id", unique = true, nullable = false, 
		insertable = true, updatable = true)
	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}
	
	@Column(name = "address1", unique = false, nullable = true, 
			insertable = true, updatable = true, length = 45)
	public String getAddress1()
	{
		return address1;
	}

	public void setAddress1(String address1)
	{
		this.address1 = address1;
	}

	@Column(name = "address2", unique = false, nullable = true, 
			insertable = true, updatable = true, length = 45)
	public String getAddress2()
	{
		return address2;
	}

	public void setAddress2(String address2)
	{
		this.address2 = address2;
	}

	@Column(name = "city", unique = false, nullable = true, 
			insertable = true, updatable = true, length = 45)
	public String getCity()
	{
		return city;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	@Column(name = "state", unique = false, nullable = true, 
			insertable = true, updatable = true, length = 45)
	public String getState()
	{
		return state;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	@Column(name = "zipcode", unique = false, nullable = true, 
			insertable = true, updatable = true, length = 10)
	public String getZipcode()
	{
		return zipcode;
	}

	public void setZipcode(String zipcode)
	{
		this.zipcode = zipcode;
	}

}
