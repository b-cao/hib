package cs4347.hibernateProject.ecomm.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Purchase", uniqueConstraints = {})
public class Purchase 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id", unique = true, nullable = false, 
		insertable = true, updatable = true, precision = 10, 
		scale = 0)
	private Long id;
	
	@Column(name = "purchaseDate", unique = false, 
			nullable = true, insertable = true, updatable = true)
	private Date purchaseDate;
	
	@Column(name = "purchaseAmount", unique = false, 
			nullable = true, insertable = true, updatable = true, 
			precision = 8, scale = 2)
	private double purchaseAmount;
	
	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "customerID", unique = false, nullable = true, 
			insertable = true, updatable = true)
	private Customer customer;

	@OneToOne(cascade = {}, fetch = FetchType.LAZY)
	@JoinColumn(name = "productID", unique = false, nullable = true, 
			insertable = true, updatable = true)
	private Product product;

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	public Date getPurchaseDate()
	{
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate)
	{
		this.purchaseDate = purchaseDate;
	}

	public double getPurchaseAmount()
	{
		return purchaseAmount;
	}

	public void setPurchaseAmount(double purchaseAmount)
	{
		this.purchaseAmount = purchaseAmount;
	}

	public Customer getCustomer()
	{
		return customer;
	}

	public void setCustomer(Customer customer)
	{
		this.customer = customer;
	}

	public Product getProduct()
	{
		return product;
	}

	public void setProduct(Product product)
	{
		this.product = product;
	}

}
